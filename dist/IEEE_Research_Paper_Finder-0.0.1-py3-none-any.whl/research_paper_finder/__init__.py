class finder:
    def __init__(self):
        print("Research Paper Finder")