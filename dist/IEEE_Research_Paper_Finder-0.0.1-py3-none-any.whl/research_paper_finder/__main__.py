def main():
    print("HEllo world")
       


if __name__ == '__main__':
    main()